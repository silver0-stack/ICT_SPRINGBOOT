package org.myweb.first.notice.model.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.myweb.first.common.Paging;
import org.myweb.first.common.Search;
import org.myweb.first.notice.jpa.repository.NoticeRepository;
import org.myweb.first.notice.model.dto.Notice;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class NoticeService {
	// JPA 가 제공하는 기본 메소드 사용을 하려면
	private final NoticeRepository noticeRepository;

	public Notice selectLast() {
		return null;
	}

	public ArrayList<Notice> selectSearchTitle(String keyword) {
		return null;
	}

	@Transactional
	public Notice insertNotice(Notice notice) {
		// save(Entity) : Entity 메소드 사용
		// JPA 가 제공, insert 문, update 문 처리
		return noticeRepository.save(notice.toEntity()).toDto();
	}

	public ArrayList<Notice> selectTop3() {
		return null;
	}

	public Notice selectNotice(int noticeNo) {
		return null;
	}

	public int updateAddReadCount(int noticeNo) {
		return 0;
	}

	public ArrayList<Notice> selectList(Paging paging) {
		return null;
	}

	public int selectListCount() {
		return 0;
	}

	public int deleteNotice(int noticeNo) {
		return 0;
	}

	public int updateNotice(Notice notice) {
		return 0;
	}

	//검색용 메소드 --------------------------------------------------------

	public ArrayList<Notice> selectSearchTitle(Search search) {
		return null;
	}

	public int selectSearchTitleCount(String keyword) {
		return 0;
	}

	public ArrayList<Notice> selectSearchContent(Search search) {
		return null;
	}

	public int selectSearchContentCount(String keyword) {
		return 0;
	}

	public ArrayList<Notice> selectSearchDate(Search search) {
		return null;
	}

	public int selectSearchDateCount(Search search) {
		return 0;
	}

}